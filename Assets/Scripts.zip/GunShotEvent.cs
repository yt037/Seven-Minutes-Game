using System.Collections;
using UnityEngine;

public class GunshotEventAudio : MonoBehaviour
{
    [SerializeField] private float gunshotDelay = 0.25f;
    [SerializeField] private float collapseDelay = 0.1f;

    private NPC npc;

    private void Awake()
    {
        npc = GetComponent<NPC>();
    }

    public void PlayShotSequence()
    {
        StartCoroutine(ShotSequence());
    }

    private IEnumerator ShotSequence()
    {
    
        if (AudioManager.Instance != null)
            AudioManager.Instance.Play(GameIds.SfxScream);

        yield return new WaitForSeconds(gunshotDelay);
       
        if (AudioManager.Instance != null)
            AudioManager.Instance.Play(GameIds.SfxGunshot);

        yield return new WaitForSeconds(collapseDelay);

        if (npc != null)
            npc.Collapse();
    }
}